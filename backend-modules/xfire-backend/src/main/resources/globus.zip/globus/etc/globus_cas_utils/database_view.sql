-- View status after running tests
select * from trust_anchor_table;
select * from object_table;
select * from object_group_entry;
select * from object_group_table;
select * from namespace_table;
select * from user_group_entry;
select * from user_group_table;
select * from user_table;
select * from service_action_group_entry;
select * from service_action_group;
select * from service_type_action;
select * from service_type;
select * from policy_table;
