#!/bin/bash
cat $GLOBUS_LOCATION/etc/glue-batch-test.xml 
