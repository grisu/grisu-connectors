#!/bin/bash
cat $GLOBUS_LOCATION/etc/glue-cluster-test.xml 
