#!/bin/sh

cat <<FIN
<?xml version="1.0" encoding="UTF-8"?>
<exampleTriggerActionScriptOutput>
    <description>
        This is example output fabricated for the MDS TriggerService.
        In a real deployment, the script generating this output would
        actually perfom some useful trigger action.
        The script input was: 
        $1
    </description>
    <time>$(date)</time>
</exampleTriggerActionScriptOutput>
FIN